package controller;
import model.Alumno;
import model.Curso;
import model.Inscripciones;
import services.DatabaseConnector;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class ControllerIE {
    ArrayList<Alumno> alumnos = new ArrayList<>();
    ArrayList<Curso> cursos = new ArrayList<>();

    DatabaseConnector connection = new DatabaseConnector();
    ResultSet rs;


    public void AgregarAlumno(Scanner scanner){
        System.out.print("Ingresa el código para el alumno: ");
        int ID_ALUMNOS = Integer.parseInt(scanner.nextLine());
        if (ID_ALUMNOS != (int)ID_ALUMNOS){
            System.out.println("el codigo debe de ser de tipo numero");
        }

        System.out.print("Ingresa el apellido: ");
        String APELLIDO = scanner.nextLine();

        System.out.print("Ingresa el nombre: ");
        String NOMBRES = scanner.nextLine();

        System.out.print("Ingresa la fecha de nacimiento ejemplo(2007-07-25): ");
        String FECHA_NACIMIENTO = scanner.nextLine();

        System.out.print("Ingresa el número de teléfono: ");
        int TELEFONO = Integer.parseInt(scanner.nextLine());
        Alumno alumno = new Alumno(ID_ALUMNOS,APELLIDO,NOMBRES,FECHA_NACIMIENTO,TELEFONO);
        alumnos.add(alumno);

        try {
            String sql = "INSERT INTO ALUMNOS(ID_ALUMNOS, APELLIDO,NOMBRES, FECHA_NACIMIENTO, TELEFONO) VALUES( ?, ? ,? ,TO_DATE(?, 'YYYY-MM-DD') ,? )";
            connection.getConnection();
            PreparedStatement ps = connection.getConnection().prepareStatement(sql);
            ps.setInt(1, ID_ALUMNOS);
            ps.setString(2,APELLIDO);
            ps.setString(3,NOMBRES);
            ps.setString(4,FECHA_NACIMIENTO);
            ps.setInt(5,TELEFONO);

            int filasAfectadas = ps.executeUpdate();
            if(filasAfectadas > 0){
                System.out.println("Se ha registrado un nuevo alumno");
            }else{
                System.out.println("Error al registrar alumno");
            }
            ps.close();
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }



    public void ImprimirTodosLosAlumnos(){
        try{
            String sql = "SELECT * FROM ALUMNOS ORDER BY ID_ALUMNOS";

            connection.getConnection();
            PreparedStatement ps = connection.getConnection().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                int ID_ALUMNOS = rs.getInt("ID_ALUMNOS");
                String APELLIDO = rs.getString("APELLIDO");
                String NOMBRES = rs.getString("NOMBRES");
                String FECHA_NACIMIENTO = rs.getString("FECHA_NACIMIENTO");
                int TELEFONO = rs.getInt("TELEFONO");

                System.out.println(
                        "Código: " + ID_ALUMNOS +
                                " - Apellidos: " + APELLIDO +
                                " - Nombres: " + NOMBRES +
                                " - Fecha de nacimiento: " + FECHA_NACIMIENTO +
                                " - Teléfono: " + TELEFONO
                );
            }
            ps.close();
            rs.close();
        }catch (SQLException e){
            System.out.print(e.getMessage());
        }
    }



    public void AgregarCurso(Scanner scanner){
        System.out.print("Ingresa el código para el curso: ");
        int ID_CURSOS = Integer.parseInt(scanner.nextLine());
        if (ID_CURSOS != (int)ID_CURSOS){
            System.out.println("el codigo debe de ser de tipo numero");
        }

        System.out.print("Ingresa el nombre del curso: ");
        String NOMBRE_CURSOS = scanner.nextLine();

        System.out.print("Ingresa el credito (10.0): ");
        double CREDITO = Double.parseDouble(scanner.nextLine());

        Curso cursos1 = new Curso(ID_CURSOS,NOMBRE_CURSOS,CREDITO);
        cursos.add(cursos1);

        try {
            String sql = "INSERT INTO CURSOS(ID_CURSOS, NOMBRE_CURSOS, CREDITO) VALUES( ?, ? ,? )";
            connection.getConnection();
            PreparedStatement ps = connection.getConnection().prepareStatement(sql);
            ps.setInt(1, ID_CURSOS);
            ps.setString(2,NOMBRE_CURSOS);
            ps.setDouble(3,CREDITO);

            int filasAfectadas = ps.executeUpdate();
            if(filasAfectadas > 0){
                System.out.println("Se ha registrado un nuevo alumno");
            }else{
                System.out.print("Error al registrar alumno");
            }
            ps.close();
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }



    public void ImprimirTodosLosCursos(){
        try{
            String sql = "SELECT * FROM CURSOS ORDER BY ID_CURSOS";
            connection.getConnection();
            PreparedStatement ps = connection.getConnection().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()){
                int ID_CURSOS= rs.getInt("ID_CURSOS");
                String NOMBRE_CURSOS= rs.getString("NOMBRE_CURSOS");
                double CREDITO= rs.getDouble("CREDITO");

                System.out.println(
                        "ID Curso: " + ID_CURSOS +
                                " - Nombre: " + NOMBRE_CURSOS +
                                " - Crédito: " + CREDITO
                );
            }
            ps.close();
            rs.close();
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }



    public void AgregarInscripcion(Scanner scanner) {
        try {
            System.out.print("Ingrese ID de inscripción: ");
            int ID_INSCRIPCIONES = Integer.parseInt(scanner.nextLine());
            System.out.print("Ingrese ID del alumno: ");
            int ID_ALUMNOS = Integer.parseInt(scanner.nextLine());
            System.out.print("Ingrese ID del curso: ");
            int ID_CURSOS = Integer.parseInt(scanner.nextLine());

            String sql = "INSERT INTO INSCRIPCIONES(ID_INSCRIPCIONES, ID_ALUMNOS, ID_CURSOS, FECHA_INSCRIPCION) VALUES(?, ?, ?, SYSDATE)";
            connection.getConnection();
            PreparedStatement ps = connection.getConnection().prepareStatement(sql);
            ps.setInt(1, ID_INSCRIPCIONES);
            ps.setInt(2, ID_ALUMNOS);
            ps.setInt(3, ID_CURSOS);

            int filasAfectadas = ps.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Se ha registrado una nueva inscripción");
            } else {
                System.out.println("Error al registrar inscripción");
            }
            ps.close();
        } catch (SQLException e) {
            System.out.print(e.getMessage());
        }
    }



    public void ImprimirTodasLasInscripciones() {
        try {
            String sql = """
            SELECT i.ID_INSCRIPCIONES,
                   a.APELLIDO,
                   a.NOMBRES,
                   c.NOMBRE_CURSOS,
                   TO_CHAR(i.FECHA_INSCRIPCION, 'DD/MM/YYYY') AS FECHA_INSCRIPCION
            FROM INSCRIPCIONES i
            INNER JOIN ALUMNOS a ON i.ID_ALUMNOS = a.ID_ALUMNOS
            INNER JOIN CURSOS c ON i.ID_CURSOS = c.ID_CURSOS
            ORDER BY a.APELLIDO
        """;

            connection.getConnection();
            PreparedStatement ps = connection.getConnection().prepareStatement(sql);
            rs = ps.executeQuery();

            System.out.println(" LISTA DE INSCRIPCIONES ");
            while (rs.next()) {
                int ID_INSCRIPCIONES = rs.getInt("ID_INSCRIPCIONES");
                String APELLIDO = rs.getString("APELLIDO");
                String NOMBRES = rs.getString("NOMBRES");
                String NOMBRE_CURSOS = rs.getString("NOMBRE_CURSOS");
                String FECHA_INSCRIPCION = rs.getString("FECHA_INSCRIPCION");

                System.out.println(
                        "Alumno: " + NOMBRES + " " + APELLIDO +
                                " - ID Inscripción: " + ID_INSCRIPCIONES +
                                " - Curso: " + NOMBRE_CURSOS +
                                " - Fecha: " + FECHA_INSCRIPCION
                );
            }
            ps.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

}




