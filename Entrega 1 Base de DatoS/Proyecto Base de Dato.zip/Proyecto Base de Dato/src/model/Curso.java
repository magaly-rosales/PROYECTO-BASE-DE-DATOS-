package model;

public class Curso {
    private int ID_CURSOS;
    private String NOMBRE_CURSOS;
    private double CREDITO;

    public Curso(int ID_CURSOS, String NOMBRE_CURSOS, double CREDITO) {
        this.ID_CURSOS = ID_CURSOS;
        this.NOMBRE_CURSOS = NOMBRE_CURSOS;
        this.CREDITO = CREDITO;
    }

    public void setID_CURSOS(int ID_CURSOS) {
        this.ID_CURSOS = ID_CURSOS;
    }

    public int getID_CURSOS() {
        return ID_CURSOS;
    }

    public void setNOMBRE_CURSOS(String NOMBRE_CURSOS) {
        this.NOMBRE_CURSOS = NOMBRE_CURSOS;
    }

    public String getNOMBRE_CURSOS() {
        return NOMBRE_CURSOS;
    }

    public void setCREDITO(double CREDITO) {
        this.CREDITO = CREDITO;
    }

    public double getCREDITO() {
        return CREDITO;
    }


}