package model;

public class Alumno {

    private int ID_ALUMNOS;
    private String APELLIDO;
    private String NOMBRES;
    private String FECHA_NACIMIENTO;
    private int TELEFONO;

    public Alumno(int ID_ALUMNOS, String APELLIDO, String NOMBRES, String FECHA_NACIMIENTO, int TELEFONO) {
        this.ID_ALUMNOS = ID_ALUMNOS;
        this.APELLIDO = APELLIDO;
        this.NOMBRES = NOMBRES;
        this.FECHA_NACIMIENTO = FECHA_NACIMIENTO;
        this.TELEFONO = TELEFONO;
    }


    public void setID_ALUMNOS(int ID_ALUMNOS) {
        this.ID_ALUMNOS = ID_ALUMNOS;
    }
    public int getID_ALUMNOS() {
        return ID_ALUMNOS;
    }


    public void setAPELLIDO(String APELLIDO) {
        this.APELLIDO = APELLIDO;
    }
    public String getAPELLIDO() {
        return APELLIDO;
    }


    public void setNOMBRES(String NOMBRES) {
        this.NOMBRES = NOMBRES;
    }
    public String getNOMBRES() {
        return NOMBRES;
    }


    public void setFECHA_NACIMIENTO(String FECHA_NACIMIENTO) {
        this.FECHA_NACIMIENTO = FECHA_NACIMIENTO;
    }
    public String getFECHA_NACIMIENTO() {
        return FECHA_NACIMIENTO;
    }


    public void setTELEFONO(int TELEFONO) {
        this.TELEFONO = TELEFONO;
    }
    public int getTELEFONO() {
        return TELEFONO;
    }

    public void Datos(){
        System.out.println("CÓDIGO: "+ID_ALUMNOS+" APELLIDOS: "+APELLIDO+" NOMBRES: "+NOMBRES+" FECHA DE NACIMIENTO: "+FECHA_NACIMIENTO+" TELÉFONO: "+TELEFONO);
    }

}