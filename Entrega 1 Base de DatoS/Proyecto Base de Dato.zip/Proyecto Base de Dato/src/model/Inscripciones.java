package model;

public class Inscripciones {
    private int ID_INSCRIPCIONES;
    private int ID_ALUMNOS;
    private int ID_CURSOS;
    private String FECHA_INSCRIPCION;

    public Inscripciones(int ID_INSCRIPCIONES, int ID_ALUMNOS, int ID_CURSOS, String FECHA_INSCRIPCION) {
        this.ID_INSCRIPCIONES = ID_INSCRIPCIONES;
        this.ID_ALUMNOS = ID_ALUMNOS;
        this.ID_CURSOS = ID_CURSOS;
        this.FECHA_INSCRIPCION = FECHA_INSCRIPCION;
    }

    public int getID_INSCRIPCIONES() {
        return ID_INSCRIPCIONES;
    }
    public int getID_ALUMNOS() {
        return ID_ALUMNOS;
    }
    public int getID_CURSOS() {
        return ID_CURSOS;
    }
    public String getFECHA_INSCRIPCION() {
        return FECHA_INSCRIPCION;
    }
    public void setID_INSCRIPCIONES(int ID_INSCRIPCIONES) {
        this.ID_INSCRIPCIONES = ID_INSCRIPCIONES;
    }
    public void setID_ALUMNOS(int ID_ALUMNOS) {
        this.ID_ALUMNOS = ID_ALUMNOS;
    }
    public void setID_CURSOS(int ID_CURSOS) {
        this.ID_CURSOS = ID_CURSOS;
    }
    public void setFECHA_INSCRIPCION(String FECHA_INSCRIPCION) {
        this.FECHA_INSCRIPCION = FECHA_INSCRIPCION;
    }
}