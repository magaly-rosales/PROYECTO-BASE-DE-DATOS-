package view;
import controller.ControllerIE;
import services.DatabaseConnector;

import java.util.Scanner;

public class ViewMain {
    Scanner scanner = new Scanner(System.in);
    ControllerIE  controllerIE = new ControllerIE();
    public void ejecutando() {
        boolean execute = true;
        while (execute) {
            System.out.println("1. Registrar Alumnos");
            System.out.println("2. Mostrar Alumnos");
            System.out.println("3. Agregar Curso");
            System.out.println("4. Mostrar Curso");
            System.out.println("5. Registrar Inscripción");
            System.out.println("6. Mostrar Inscripciones");
            System.out.println("7. Salir");
            System.out.print("Selecciona una opción: ");
            int option = Integer.parseInt(scanner.nextLine());
            switch (option) {
                case 1:
                    controllerIE.AgregarAlumno(scanner);

                    break;
                case 2:
                    controllerIE.ImprimirTodosLosAlumnos();
                    break;

                case 3:
                    controllerIE.AgregarCurso(scanner);
                    break;

                case 4:
                    controllerIE.ImprimirTodosLosCursos();
                    break;

                case 5:
                    controllerIE.AgregarInscripcion(scanner);
                    break;

                case 6:
                    controllerIE.ImprimirTodasLasInscripciones();
                    break;

                case 7:
                    System.out.println("Fin del programa");
                    execute = false;
                    break;
                default:
                    System.out.println("Ingresa una opción válida");
                    break;
            }
        }
    }
}