import view.ViewMain;

public class Main {
    public static void main(String[] args) {
        ViewMain viewMain = new ViewMain();
        viewMain.ejecutando();

    }
}